import server from "./index.js";

server.listen(5000, () => {
  console.log("server is listening at port 5000");
});
