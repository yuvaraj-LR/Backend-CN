export const newUser = (req, res) => {
  
  return res.status(201).send("user added !");
};
