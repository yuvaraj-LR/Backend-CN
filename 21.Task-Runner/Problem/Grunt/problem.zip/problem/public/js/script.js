let demo = document.getElementById("demo");

document.addEventListener("click", (e) => {
    demo.style.backgroundColor = "#000";
    demo.style.color = "fff";
    demo.style.border = "3px solid red"
})

