// Complete the server.js file to make user's add, delete and update the todos.
