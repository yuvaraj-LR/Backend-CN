// make the necessary imports here
// implement the below schema
const messageSchema = 





